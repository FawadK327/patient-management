<?php $__env->startSection('title', 'Doctor'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <div class="card">
                <div class="card-head">
                    <header class="text-capitalize">all doctors</header>
                    <div class="tools">
                        <a class="btn btn-primary ink-reaction" href="<?php echo e(route('doctor.create')); ?>">
                            <i class="md md-add"></i>
                            Add
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="doctor-datatable">
                            <thead>
                                <tr>
                                    <th><?php echo e(strtoupper(__('name'))); ?></th>
                                    <th><?php echo e(strtoupper(__('address'))); ?></th>
                                    <th><?php echo e(strtoupper(__('phone no'))); ?></th>
                                    <th><?php echo e(strtoupper(__('email'))); ?></th>
                                    <th><?php echo e(strtoupper(__('age'))); ?></th>
                                    <th><?php echo e(strtoupper(__('gender'))); ?></th>
                                    <th><?php echo e(strtoupper(__('department'))); ?></th>
                                    <th><?php echo e(strtoupper(__('action'))); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/datatables/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('vendor/datatables/datatables.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        var table = $('#doctor-datatable').DataTable({
            "dom": "rBftip",
            "language": {
                "processing": "<h2 id='dt_loading'><span class='fa fa - spinner fa-pulse'></span> Loading...</h2>"
            },
            "buttons": [
                'pageLength', 'colvis'
            ],
            "order": [],
            "processing": true,
            "serverSide": true,
            "ajax": {
                "type": "POST",
                "data": {"_token": '<?php echo e(csrf_token()); ?>'},
                "url": '<?php echo e(route('doctor.datatable')); ?>'
            },
            "pageLength": "25",
            "columns": [
                {"data": "name", "name": "name", "searchable": "false"},
                {"data": "address", "name": "address"},
                {"data": "phone", "name": "phone"},
                {"data": "email", "name": "email"},
                {"data": "age", "name": "age"},
                {"data": "gender", "name": "gender"},
                {"data": "department", "name": "department"},
                {
                    "data": "username", "class": "text-right", "orderable": false, "render": function (data) {
                    return "<a href='/doctor/" + data + "/edit' class='btn btn-default'> Edit </a>" +
                        "<button data-url='/doctor/" + data + "/destroy' class='btn btn-danger item-delete'> Delete </button>";
                }
                }
            ]
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>