<div class="row">
    <div class="col-md-12">
        <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-head">
                <header><?php echo $header; ?></header>
                <div class="tools visible-xs">
                    <a class="btn btn-default btn-ink" onclick="history.go(-1);return false;">
                        <i class="md md-arrow-back"></i>
                        Back
                    </a>
                    <input type="submit" name="draft" class="btn btn-info ink-reaction" value="Save Draft">
                    <input type="submit" name="publish" class="btn btn-primary ink-reaction" value="Publish">
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?php echo e(Form::text('name',old('name'),['class'=>'form-control', 'required'])); ?>

                            <?php echo e(Form::label('name','Name*')); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?php echo e(Form::text('address',old('address'),['class'=>'form-control', 'required'])); ?>

                            <?php echo e(Form::label('address','Address*')); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?php echo e(Form::text('phone',old('phone'),['class'=>'form-control', 'required'])); ?>

                            <?php echo e(Form::label('phone','Phone No.*')); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?php echo e(Form::text('skills',old('skills'),['class'=>'form-control', 'required'])); ?>

                            <?php echo e(Form::label('skills','Skills*')); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?php echo e(Form::text('admit_type',old('admit_type'),['class'=>'form-control', 'required'])); ?>

                            <?php echo e(Form::label('admit_type','Admit Type*')); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?php echo e(Form::time('admit_time',old('admit_time'),['class'=>'form-control', 'required'])); ?>

                            <?php echo e(Form::label('admit_time','Admit Time*')); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?php echo e(Form::text('medicine',old('medicine'),['class'=>'form-control', 'required'])); ?>

                            <?php echo e(Form::label('medicine','Medicine*')); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?php echo e(Form::text('ward_no',old('ward_no'),['class'=>'form-control', 'required'])); ?>

                            <?php echo e(Form::label('ward_no','Ward No*')); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?php echo e(Form::text('room_no',old('room_no'),['class'=>'form-control', 'required'])); ?>

                            <?php echo e(Form::label('room_no','Room No*')); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <select name="doctor_id" class="form-control" required>
                                <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($doctor); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo e(Form::label('doctor_id','Doctor*')); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <select name="staff_id" class="form-control" required>
                                <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($staff); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo e(Form::label('staff_id','Staff*')); ?>

                        </div>
                    </div>
                </div>
                <div class="card-actionbar">
                    <div class="card-actionbar-row">
                        <button type="reset" class="btn btn-default ink-reaction">Reset</button>
                        <input type="submit" name="draft" class="btn btn-info ink-reaction" value="Submit">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-affix affix-4">
            <div class="card-head">
                <div class="tools">
                    <a class="btn btn-default btn-ink" href="<?php echo e(route('doctor.index')); ?>">
                        <i class="md md-arrow-back"></i>
                        Back
                    </a>
                </div>
            </div>
            <?php echo e(Form::hidden('view', old('view'))); ?>

        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('backend/css/libs/dropify/dropify.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('/backend/css/bootstrap-select.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/js/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/libs/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/libs/dropify/dropify.min.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/js/bootstrap-select.js')); ?>"></script>
<script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
<script>
    CKEDITOR.replace('my-editor', {
        filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
        filebrowserImageUploadUrl: '/laravel-filemanager/upload?type=Images&_token=<?php echo e(csrf_token()); ?>',
        filebrowserBrowseUrl: '/laravel-filemanager?type=Files',
        filebrowserUploadUrl: '/laravel-filemanager/upload?type=Files&_token=<?php echo e(csrf_token()); ?>'
    });
</script>
<?php $__env->stopPush(); ?>