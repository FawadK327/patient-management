<?php $__env->startSection('title', 'Appointment'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <?php echo e(Form::model($appointment, ['route' =>['appointment.update', $appointment->username],'class'=>'form form-validate','role'=>'form', 'files'=>true, 'novalidate'])); ?>

            <?php echo e(method_field('PUT')); ?>

            <?php echo $__env->make('backend.appointment.partials.form', ['header' => 'Edit Appointment <span class="text-primary">('.str_limit($appointment->name, 47).')</span>'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo e(Form::close()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>