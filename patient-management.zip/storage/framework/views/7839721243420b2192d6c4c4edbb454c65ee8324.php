<?php $__env->startSection('heading', 'Regarding Appointment from patient'); ?>

<?php $__env->startSection('content'); ?>
    <h1>
        Dear Sir/Madam,
    </h1>
    <p>
        The Patient named <?php echo e($name); ?> has taken an appointment with you for the date <?php echo e($date); ?> and time <?php echo e($time); ?>.
        You could also contact him directly in this number <?php echo e($phone); ?>.
    </p>
    <p>
        Regards,
        Patient Management System,
        Admin
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('email.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>