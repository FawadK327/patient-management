<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta name="viewport" content="width=device-width"/>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <style type="text/css" rel="stylesheet" media="all">
        /* Media Queries */
        @media  only screen and (max-width: 800px) {
            .button {
                width: 100% !important;
            }
            .responsive-full-width {
                width: 100% !important;
            }
        }
    </style>
</head>

<?php
//$logo = asset(setting('logo'));
$facebook_logo = asset(setting('facebook_logo'));
$twitter_logo = asset(setting('twitter_logo'));
$google_plus_logo = asset(setting('google_plus_logo'));
?>

<body style="<?php echo e(config('emailstyle.body')); ?>" itemscope itemtype="http://schema.org/EmailMessage">
<table width="100%" cellpadding="0" cellspacing="0">
    <tr>
        <td style="<?php echo e(config('emailstyle.email-wrapper')); ?>" align="center">
            <table class="responsive-full-width" style="<?php echo e(config('emailstyle.email-content')); ?>" cellpadding="0" cellspacing="0">
                <!-- Logo -->
                <tr>
                    <td style="<?php echo e(config('emailstyle.email-masthead')); ?>">
                        <a style="<?php echo e(config('emailstyle.font-family')); ?> <?php echo e(config('emailstyle.email-masthead_name')); ?>" href="<?php echo e(url('/')); ?>" target="_blank">
                            <img src="" width="90" height="90" alt='<?php echo e(config('website.title')); ?>'/>
                            <br/>
                            <span style="<?php echo e(config('emailstyle.anchor')); ?>"><?php echo e(config('website.title')); ?></span>
                        </a>
                    </td>
                </tr>

                <!-- email Body -->
                <tr>
                    <td style="<?php echo e(config('emailstyle.email-body')); ?>" width="100%">
                        <table style="<?php echo e(config('emailstyle.email-body_inner')); ?>" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                                <td style="<?php echo e(config('emailstyle.font-family')); ?> <?php echo e(config('emailstyle.email-body_cell')); ?>">
                                    <!-- Heading -->
                                    <h1 style="<?php echo e(config('emailstyle.header-1')); ?>">
                                        <?php echo $__env->yieldContent('heading'); ?>
                                    </h1>

                                    <?php echo $__env->yieldContent('content'); ?>

                                    <br>
                                    <p style="<?php echo e(config('emailstyle.paragraph')); ?>">
                                        <!-- Salutation -->Regards,<br>
                                        <?php echo e(config('website.title')); ?><br>
                                        <?php echo setting('address'); ?>

                                        <?php echo e(setting('phone')); ?>

                                    </p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <!-- Footer -->
                <tr>
                    <td>
                        <table style="<?php echo e(config('emailstyle.email-footer')); ?>" align="center" width="570" cellpadding="0" cellspacing="0">
                            <tr>
                                <td style="<?php echo e(config('emailstyle.font-family')); ?> <?php echo e(config('emailstyle.email-footer_cell')); ?>">
                                    <p style="<?php echo e(config('emailstyle.paragraph-sub')); ?>">
                                        &copy; <?php echo e(date('Y')); ?>

                                        <a style="<?php echo e(config('emailstyle.anchor')); ?>" href="<?php echo e(url('/')); ?>" target="_blank"><?php echo e(config('website.title')); ?></a>
                                        . All rights reserved.
                                    </p>
                                    <p style="<?php echo e(config('emailstyle.paragraph-sub')); ?>">
                                        <a href="<?php echo e(setting( 'facebook' )); ?>" style="<?php echo e(config('emailstyle.social-anchor')); ?>">
                                            <img src="<?php echo e($message->embed($facebook_logo)); ?>" width="30" height="30" alt="facebook" style="<?php echo e(config('emailstyle.social-img')); ?>">
                                        </a>
                                        <a href="<?php echo e(setting( 'twitter' )); ?>" style="<?php echo e(config('emailstyle.social-anchor')); ?>">
                                            <img src="<?php echo e($message->embed($twitter_logo)); ?>" width="30" height="30" alt="twitter" style="<?php echo e(config('emailstyle.social-img')); ?>">
                                        </a>
                                        <a href="<?php echo e(setting( 'google_plus' )); ?>" style="<?php echo e(config('emailstyle.social-anchor')); ?>">
                                            <img src="<?php echo e($message->embed($google_plus_logo)); ?>" width="30" height="30" alt="google_plus" style="<?php echo e(config('emailstyle.social-img')); ?>">
                                        </a>
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>
