<?php $__env->startSection('title', 'Prescription'); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <div class="card">
                <div class="card-head">
                    <header class="text-capitalize">All prescriptions</header>
                    <div class="tools">
                        <a class="btn btn-primary ink-reaction" href="<?php echo e(route('prescription.create')); ?>">
                            <i class="md md-add"></i>
                            Add Prescription
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="prescription-datatable">
                            <thead>
                            <tr>
                                <th><?php echo e(strtoupper(__('Patient name'))); ?></th>
                                <th><?php echo e(strtoupper(__('dated'))); ?></th>
                                <th><?php echo e(strtoupper(__('Description'))); ?></th>
                                <!-- <th><?php echo e(strtoupper(__('age'))); ?></th>
                                <th><?php echo e(strtoupper(__('gender'))); ?></th> -->
                                <th><?php echo e(strtoupper(__('action'))); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/datatables/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('vendor/datatables/datatables.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        var table = $('#prescription-datatable').DataTable({
            "dom": "rBftip",
            "language": {
                "processing": "<h2 id='dt_loading'><span class='fa fa - spinner fa-pulse'></span> Loading...</h2>"
            },
            "buttons": [
                'pageLength', 'colvis'
            ],
            "order": [],
            "processing": true,
            "serverSide": true,
            "ajax": {
                "type": "POST",
                "data": {"_token": '<?php echo e(csrf_token()); ?>'},
                "url": '<?php echo e(route('prescription.datatable')); ?>'
            },
            "pageLength": "25",
            "columns": [
                {"data": "patient_name", "name": "patient_name", "searchable": "false"},
                {"data": "date", "name": "date"},
                {"data": "description", "name": "description"},
                {"data": "action", "name": "action"},
                
            ]
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>