<?php $__env->startSection('title', 'Prescription'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <?php echo e(Form::model($prescription, ['route' =>['prescription.update', $prescription->id],'class'=>'form form-validate','role'=>'form', 'files'=>true, 'novalidate'])); ?>

            <?php echo e(method_field('PUT')); ?>

            <?php echo $__env->make('backend.prescription.partials.form', ['header' => 'Edit Prescription'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo e(Form::close()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>