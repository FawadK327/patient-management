<?php $__env->startSection('title', 'Patient'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <?php echo e(Form::model($patient, ['route' =>['patient.update', $patient->id],'class'=>'form form-validate','role'=>'form', 'files'=>true, 'novalidate'])); ?>

            <?php echo e(method_field('PUT')); ?>

            <?php echo $__env->make('backend.patient.partials.form', ['header' => 'Edit Patient <span class="text-primary">('.str_limit($patient->name, 47).')</span>'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo e(Form::close()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>