The topic for my academic project is PATIENT MANAGEMENT SYSTEM.
As name suggests it is the information system that is developed by the hospital in managing the records of the people that are involved in the organization.

This system provide various benefits in an organization that helps storing records in an organization in an easier manner.
PATIENT MANAGEMNET SYSTEM provide various features and functions.

The main advantage are as follows :
1. To store record that are obtained in the hospital
2. To provide different facility for helping to store and register patient and inpatient.

Inpatient are those patient who are admitted inside the hospital. Moreover it provide the facility of dealing with appointment in a hospital.